package com.examle.adanced.list;

import java.util.ArrayList;
import java.util.List;

public class ListEx {

    public static void main(String[] args) {
        List list = new ArrayList();
        list.add("One");
        list.add(100);
        list.add(true);
        list.add(5000.0);

        for (Object o : list) {
            System.out.println(o);
        }

        List<Integer> intList = new ArrayList();
        System.out.println("Size: " + intList.size());
        Long startTime = System.currentTimeMillis();
        for (int i = 1; i <= 100000000; i++) {
            intList.add(i);
        }
        Long endTime = System.currentTimeMillis();
        Long elaspedTime = endTime - startTime;
        System.out.println("Exact Time(Ms): " + elaspedTime);
        System.out.println("Size: " + intList.size());
    }
}
