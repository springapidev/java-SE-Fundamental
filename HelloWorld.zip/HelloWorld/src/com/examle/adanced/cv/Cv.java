package com.examle.adanced.cv;

import java.util.ArrayList;
import java.util.List;

public class Cv {

    public static void main(String[] args) {
        List<Student> list = new ArrayList();

        List<EducationHistory> eduListForrajib = new ArrayList();
        eduListForrajib.add(new EducationHistory(1, "SSC", "AK Pilot High School", new Board(1, "Dhaka"), 5.0f, "A+", 2010));
        eduListForrajib.add(new EducationHistory(2, "HSC", "Pilot College School", new Board(2, "Oxford"), 5.0f, "A+", 2012));
        eduListForrajib.add(new EducationHistory(3, "BSC", "DU", new Board(1, "DU"), 5.0f, "A+", 2014));
        eduListForrajib.add(new EducationHistory(4, "MSC", "DU", new Board(1, "DU"), 5.0f, "A+", 2015));
        List<EducationHistory> eduListHimel = new ArrayList();
        eduListHimel.add(new EducationHistory(1, "O", "MapelLieap", new Board(1, "Dhaka"), 5.0f, "A+", 2016));
        eduListHimel.add(new EducationHistory(2, "A", "MapelLieap", new Board(1, "Dhaka"), 5.0f, "A+", 2018));

        list.add(new Student(100, "Mr. Rajib Sarkar", "rajib@gmail.com", "01686000000", new Department(1, "Software"), eduListForrajib));
        list.add(new Student(101, "Mr. Himel", "himel@gmail.com", "01686000022", new Department(1, "Software"), eduListHimel));

        for (Student student : list) {
            System.out.println(student);
        }
    }
}
