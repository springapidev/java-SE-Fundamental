package com.examle.adanced.cv;

import java.util.List;

public class Student {

    private int id;
    private String studentName;
    private String email;
    private String mobile;
    private Department department;
    private List<EducationHistory> educationHistorys;

    public Student() {
    }

    public Student(int id, String studentName, String email, String mobile, Department department,
            List<EducationHistory> educationHistorys) {
        this.id = id;
        this.studentName = studentName;
        this.email = email;
        this.mobile = mobile;
        this.department = department;
        this.educationHistorys = educationHistorys;
    }

    @Override
    public String toString() {
        return "Student{" + "id=" + id + ", studentName=" + studentName + ", email=" + email + ", mobile=" + mobile + ", department=" + department + ", educationHistorys=" + educationHistorys + '}';
    }

    
  

}
