package com.examle.adanced.cv;

public class EducationHistory {

    private int id;
    private String examName;
    private String institueName;
    private Board board;
    private float cgpa;
    private String grade;
    private int passingYear;

    public EducationHistory(int id, String examName, String institueName, Board board, float cgpa, String grade, int passingYear) {
        this.id = id;
        this.examName = examName;
        this.institueName = institueName;
        this.board = board;
        this.cgpa = cgpa;
        this.grade = grade;
        this.passingYear = passingYear;
    }

    @Override
    public String toString() {
        return "EducationHistory{" + "id=" + id + ", examName=" + examName + ", institueName=" + institueName + ", board=" + board + ", cgpa=" + cgpa + ", grade=" + grade + ", passingYear=" + passingYear + '}';
    }

   
    
}
