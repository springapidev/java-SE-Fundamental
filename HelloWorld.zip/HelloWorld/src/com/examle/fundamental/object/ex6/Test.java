package com.examle.fundamental.object.ex6;

public class Test {

    public static void main(String[] args) {
        Dog dog6 = new Dog("Mr. Tom", "Red");
        System.out.println(dog6);
        dog6.setNoOfLegs(4);
        System.out.println(dog6);
    }

}
