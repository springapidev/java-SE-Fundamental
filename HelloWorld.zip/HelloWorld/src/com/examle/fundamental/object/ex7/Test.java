package com.examle.fundamental.object.ex7;

public class Test {

    public static void main(String[] args) {
        Dog dog7 = new Dog();
        dog7.setName("Mr Tom");
        dog7.noOfLegs = 4;
        dog7.color = "Yellow";
        System.out.println(dog7);
    }

}
