package com.examle.fundamental.object.ex7;

public class Dog {

    private String name;
    int noOfLegs;
    String color;

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Dog{" + "name=" + name + ", noOfLegs=" + noOfLegs + ", color=" + color + '}';
    }

}
