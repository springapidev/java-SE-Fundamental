package com.examle.fundamental.object.ex2;

public class Test {

    public static void main(String[] args) {
        Dog dog2 = new Dog();
        System.out.println(dog2);
    }

}
