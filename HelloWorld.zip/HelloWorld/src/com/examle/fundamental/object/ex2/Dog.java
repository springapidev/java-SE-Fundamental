package com.examle.fundamental.object.ex2;

public class Dog {

    String name = "Tom";
    int noOfLegs = 4;
    String color;

    @Override
    public String toString() {
        return "Dog{" + "name=" + name + ", noOfLegs=" + noOfLegs + ", color=" + color + '}';
    }
    
    
    
    

}
