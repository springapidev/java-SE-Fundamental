package com.examle.fundamental.object.ex5;

public class Dog {

    String name;
    int noOfLegs;
    String color;

    public void setName(String name) {
        this.name = name;
    }

    public void setNoOfLegs(int noOfLegs) {
        this.noOfLegs = noOfLegs;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return "Dog{" + "name=" + name + ", noOfLegs=" + noOfLegs + ", color=" + color + '}';
    }

}
