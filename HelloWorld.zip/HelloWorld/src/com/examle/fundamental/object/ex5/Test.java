package com.examle.fundamental.object.ex5;

public class Test {

    public static void main(String[] args) {
        Dog dog5 = new Dog();
        dog5.setName("Mr. Tommmmm");
        dog5.setName("Mr. Tom");
        dog5.setNoOfLegs(4);
        dog5.setColor("Black- n - white");
        System.out.println(dog5);

    }

}
