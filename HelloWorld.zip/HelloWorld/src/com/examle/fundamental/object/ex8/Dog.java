package com.examle.fundamental.object.ex8;

public class Dog {

    private final String name;
    private final int noOfLegs;
    private final String color;

    public Dog(String name, int noOfLegs, String color) {
        this.name = name;
        this.noOfLegs = noOfLegs;
        this.color = color;
    }

    @Override
    public String toString() {
        return "Dog{" + "name=" + name + ", noOfLegs=" + noOfLegs + ", color=" + color + '}';
    }

}
