package com.examle.fundamental.object.ex8;

public class Test {

    public static void main(String[] args) {
        Dog dog8 = new Dog("Mr. Tom", 4, "Black");
        System.out.println(dog8);
    }

}
