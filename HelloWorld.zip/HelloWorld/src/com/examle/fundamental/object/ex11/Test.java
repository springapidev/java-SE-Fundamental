package com.examle.fundamental.object.ex11;

public class Test {

    public static void main(String[] args) {
        Department dep = new Department(1, "Software");
        Country country = new Country(1, "BD");
        Student s1 = new Student(101, "Mr. Sujan", 1, dep, country);

        ///////////standard
        Student s2 = new Student(102, "Mamun", 2, new Department(2, "IT"), new Country(2, "USA"));

        System.out.println(s1);
        System.out.println(s2);
       
	   System.out.println("=====================");
        Student[] students = new Student[3];
        students[0] = s1;
        students[1] = s2;
        students[2] = new Student(103, "Mr. A", 3, dep, country);

        for (Student s : students) {
            System.out.println(s);
        }

    }

}
