package com.examle.fundamental.object.ex4;

public class Dog {

    String name;
    int noOfLegs;
    String color;

    public Dog(String name, int noOfLegs, String color) {
        this.name = name;
        this.noOfLegs = noOfLegs;
        this.color = color;
    }

    @Override
    public String toString() {
        return "Dog{" + "name=" + name + ", noOfLegs=" + noOfLegs + ", color=" + color + '}';
    }

}
