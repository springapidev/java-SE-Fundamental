package com.examle.fundamental.object.ex4;

public class Test {

    public static void main(String[] args) {
        // constructor injection
        Dog dog4 = new Dog("Mr. Top", 4, "Black");
        Dog dog5 = new Dog("Mr. Jerry", 4, "white");

        System.out.println(dog4);
        System.out.println(dog5);
    }
}
