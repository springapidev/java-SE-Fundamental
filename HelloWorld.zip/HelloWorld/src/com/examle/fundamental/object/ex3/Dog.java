package com.examle.fundamental.object.ex3;

public class Dog {

    String name = "Tom";
    int noOfLegs = 4;
    String color;

    public String displayInfo() {
        return "Name: " + name + ", Legs: " + noOfLegs + ", Color: " + color;
    }

    public void showInfo() {
        System.out.println("Name: " + name + ", Legs: " + noOfLegs + ", Color: " + color);
    }
}
