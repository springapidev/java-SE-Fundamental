package com.examle.fundamental.object.ex3;

public class Test {

    public static void main(String[] args) {
        Dog dog3 = new Dog();
        dog3.showInfo();
        System.out.println(dog3.displayInfo());
        System.out.println("");
    }

}
