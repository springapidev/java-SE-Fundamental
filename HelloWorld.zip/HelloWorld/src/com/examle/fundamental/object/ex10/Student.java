package com.examle.fundamental.object.ex10;

public class Student {

    private final int id;
    private final String name;
    private final int roll;
    private final Department department;
    private final Country country;

    public Student(int id, String name, int roll, Department department, Country country) {
        this.id = id;
        this.name = name;
        this.roll = roll;
        this.department = department;
        this.country = country;
    }

    @Override
    public String toString() {
        return "Student{" + "id=" + id + ", name=" + name + ", roll=" + roll + ", department=" + department + ", country=" + country + '}';
    }
    


}
