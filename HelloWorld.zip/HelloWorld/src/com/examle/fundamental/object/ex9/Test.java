package com.examle.fundamental.object.ex9;

public class Test {

    public static void main(String[] args) {
        Department dep = new Department(1, "Software");
        Student s1 = new Student(101, "Mr. Sujan", 1, dep);

        ///////////standard
        Student s2 = new Student(102, "Mamun", 2, new Department(2, "IT"));

        System.out.println(s1);
        System.out.println(s2);

    }

}
