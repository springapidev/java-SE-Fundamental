package com.examle.fundamental.object.ex9;

public class Department {

    private final int depId;
    private final String depName;

    public Department(int depId, String depName) {
        this.depId = depId;
        this.depName = depName;
    }

    @Override
    public String toString() {
        return "Department{" + "depId=" + depId + ", depName=" + depName + '}';
    }

}
