package com.examle.fundamental.object.ex9;

public class Student {

    private final int id;
    private final String name;
    private final int roll;
    private final Department department;

    public Student(int id, String name, int roll, Department department) {
        this.id = id;
        this.name = name;
        this.roll = roll;
        this.department = department;
    }

    @Override
    public String toString() {
        return "Student{" + "id=" + id + ", name=" + name + ", roll=" + roll + ", department=" + department + '}';
    }

}
