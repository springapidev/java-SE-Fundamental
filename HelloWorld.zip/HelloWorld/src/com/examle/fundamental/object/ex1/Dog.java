package com.examle.fundamental.object.ex1;

public class Dog {

    String name = "Tom";
    int noOfLegs = 4;
    String color;

}
