package com.examle.fundamental.object.ex1;

public class Test {

    public static void main(String[] args) {
        Dog dog1 = new Dog();
        System.out.println(dog1);
        System.out.println("Name: " + dog1.name + " No Of Legs: " + dog1.noOfLegs + " Color: " + dog1.color);

    }

}
