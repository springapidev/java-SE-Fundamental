package com.examle.fundamental;

public class ArrayEx {

    public static void main(String[] args) {

        int num[] = {1, 3, 5, 7, 9, 13, 15, 17, 19, 20};
        System.out.println("Lenth: " + num.length);
        System.out.println("First el: " + num[0] + " Last: " + num[num.length - 1]);

        // print above array using for loop
        for (int i = 0; i < num.length; i++) {
            //  System.out.print(num[i] + ", ");
        }

        // single d array print differently
        for (int i : num) {
            System.out.println("= " + i);
        }

        int arrTwoD[][] = {
            {2, 3, 4, 6, 9, 10},
            {6, 5, 9, 15, 20, 1},
            {16, 25, 19, 150, 20, 11}
        };

        System.out.println("Array 2d 15: " + arrTwoD[2][3]);

        for (int oneD[] : arrTwoD) {
            for (int j : oneD) {
                System.out.print(j + ", ");
            }
            System.out.println("");
        }

// print 1 to 10
        for (int i = 1; i <= 10; i++) {
            System.out.println(i);
        }

        int[] x;
        int y[];

        int arr[];
        arr = new int[5];
        arr[0] = 100;
        arr[1] = 200;
        arr[2] = 300;
        arr[3] = 400;
        arr[4] = 500;
        //  arr[5]= 600; wrong

        System.out.println(" arr[5]: " + arr[4]);
    }
}
