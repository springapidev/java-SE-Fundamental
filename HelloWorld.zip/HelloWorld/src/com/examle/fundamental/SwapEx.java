package com.examle.fundamental;

public class SwapEx {
    /*
     write a program using swap concept
     */

    public static void main(String[] args) {
        int x = 10;
        int y = 20;
        int temp = x;
        x = y;// now value of x is 20
        y = temp;// now value of y is 10
        System.out.println("X: " + x + " Y: " + y);
        
    }
}
