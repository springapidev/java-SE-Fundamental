package com.examle.fundamental;

public class VariableConvention {

    String name = "Mr. Mamun";
    String nAme = "Mr. Mamun";
    String $name = "Mr. Mamun";
    String _name = "Mr. Mamun";
    String first_name = "Mr. Mamun";
    String name120 = "Mr. Mamun";
    // String 500first_name = "Mr. Mamun";//wrong, you can not start with number
    //camel Case, and It is best one and we shall follow
    String firstName = "Mr. Mamun";// best one
    String FirstName = "Mr. Mamun";

}
