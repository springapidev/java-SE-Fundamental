package com.examle.fundamental;

public class PrimitiveDataTypesEx {

    static byte byteVar;
    static short shortVar;
    static int intVar;
    static float floatVar;
    static long longvar;
    static double doubleVar;
    static char charVar;
    static boolean booleanVar;

    public static void main(String[] args) {
        byteVar = 127;
        intVar = 2147483647;
        longvar = 2147483648L;
        longvar = 9223372036854775807L;
        doubleVar = 9223372036854775807D;

        System.out.println("byteVar: " + byteVar);
        System.out.println("shortVar: " + shortVar);
        System.out.println("intVar: " + intVar);
        System.out.println("floatVar: " + floatVar);
        System.out.println("longvar: " + longvar);
        System.out.println("doubleVar: " + doubleVar);
        System.out.println("charVar: " + charVar);
        System.out.println("booleanVar: " + booleanVar);
        ///////
        System.out.println("Min of byteVar: " + Byte.MIN_VALUE
                + " Max of byteVar: " + Byte.MAX_VALUE);
        System.out.println("Min of shortVar: " + Short.MIN_VALUE
                + " Max of shortVar: " + Short.MAX_VALUE);
        System.out.println("Min of intVar: " + Integer.MIN_VALUE
                + " Max of intVar: " + Integer.MAX_VALUE);
        System.out.println("Min of floatVar: " + Float.MIN_VALUE
                + " Max of floatVar: " + Float.MAX_VALUE);
        System.out.println("Min of longVar: " + Long.MIN_VALUE
                + " Max of longVar: " + Long.MAX_VALUE);
        System.out.println("Min of doubleVar: " + Double.MIN_VALUE
                + " Max of doubleVar: " + Double.MAX_VALUE);

    }
}
