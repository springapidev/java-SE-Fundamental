package com.examle.fundamental.exceptions;

public class Student {

    public static int makeAvg(int n1, int n2) {
        int avg = 0;
        try {
            avg = n1 / n2;
        } catch (Exception e) {
            System.out.println("nooooo");
        }

        return avg;
    }
}
