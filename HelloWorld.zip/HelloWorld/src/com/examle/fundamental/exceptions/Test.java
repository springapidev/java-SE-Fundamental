package com.examle.fundamental.exceptions;

public class Test {

    public static void main(String[] args) {
        System.out.println(Student.makeAvg(50, 0));
        try {
            System.out.println(Student.makeAvg(50, 0));

        } catch (Exception e) {
            e.printStackTrace();
        }

        int x = 10;

        System.out.println("Hi......");
        try {
            int y = Integer.parseInt("2");
            System.out.println("Yes....." + "Rs: " + x / y);
        } catch (ArithmeticException ne) {
            System.out.println("can not be divided by zero");
            //  ae.printStackTrace();
        } catch (NumberFormatException ae) {
            System.out.println("can not be divided by zero");
            //  ae.printStackTrace();
        } catch (Exception e) {

        } finally {
            System.out.println("finalllll.........");
        }
        System.out.println("Bye.....");
    }
}
