package com.examle.fundamental;

public class VariableEx {
    /*
     Write a program name VariableEx and there 
     1. declare a instance variable
     and then initialization and used it in the main method.
     2. declare and initialization a class variable and used it in the main method.
     3. decleare a local variable and give it a value 10 , then declare another 
     variable and give prio variable value in it.
     4.declare and initialization a instance variable
     used it in the main method.
     */

    int x;// dec.....
    static int y = 500;
    int z = 100;

    public static void main(String[] args) {
        VariableEx obEx = new VariableEx();
        obEx.x = 2000;
        System.out.println("X: " + obEx.x);
        System.out.println("Y: " + y);
        int local = 10;
        int anotherVariable = local;
        System.out.println("anVa: " + anotherVariable);
        System.out.println("Z " + obEx.z);
    }

}
