package com.examle.fundamental.methods;

public class MethodArrayInputs {
    
    public static void main(String[] args) {
        int arrs[] = {2, 3, 5, 7, 1};
        System.out.println(makeSum(arrs));
        System.out.println(makeSum2(2, 3, 5, 4, 4, 4, 4, 4, 4));
    }
    
    public static int makeSum2(int... nums) {
        int sum = 0;
        for (int i : nums) {
            sum += i;
        }
        return sum;
    }
    
    public static int makeSum(int[] nums) {
        int sum = 0;
        for (int i : nums) {
            sum += i;
        }
        return sum;
    }
}
