package com.examle.fundamental.methods;

public class MethodProblem {

    public static void main(String[] args) {
        new MethodProblem().printSums(1, 10);
    }

    public void printSums(int n1, int n2) {
        int oddSum = 0, evenSum = 0, sumOfDivisibleBy3 = 0, sumOfDivisibleBy5 = 0, sumOfDivisibleBy7 = 0;
        for (int i = n1; i <= n2; i++) {
            if (isCheckOdd(i)) {
                oddSum += i;
                oddSum += 5;
            }
            if (isCheckEven(i)) {
                evenSum += i;
                evenSum += 6;
            }
            if (isCheckNumDivisibleBy3(i)) {
                sumOfDivisibleBy3 += i;
                sumOfDivisibleBy3 += 7;
            }
            if (isCheckNumDivisibleBy5(i)) {
                sumOfDivisibleBy5 += i;
                sumOfDivisibleBy5 += 8;
            }
            if (isCheckNumDivisibleBy7(i)) {
                sumOfDivisibleBy7 += i;
                sumOfDivisibleBy7 += 9;
            }
        }
        System.out.println("Odd Sum : " + oddSum);
        System.out.println("Even Sum : " + evenSum);
        System.out.println("Sum Divisible By 3: " + sumOfDivisibleBy3);
        System.out.println("Sum Divisible By 5: " + sumOfDivisibleBy5);
        System.out.println("Sum Divisible By 7: " + sumOfDivisibleBy7);

    }

    public static boolean isCheckOdd(int num) {
        if (num % 2 == 1) {
            return true;
        }
        return false;
    }

    public boolean isCheckEven(int num) {
        if (num % 2 == 0) {
            return true;
        }
        return false;
    }

    public static boolean isCheckNumDivisibleBy3(int num) {
        if (num % 3 == 0) {
            return true;
        }
        return false;
    }

    public boolean isCheckNumDivisibleBy5(int num) {
        if (num % 5 == 0) {
            return true;
        }
        return false;
    }

    public boolean isCheckNumDivisibleBy7(int num) {
        if (num % 7 == 0) {
            return true;
        }
        return false;
    }
}
