package com.examle.fundamental.methods;

public class Quiz {

    /**
     * 1. Take 3 inputs as arguments and make sum 2. Take 2 inputs as
     * arguments,1 as direct input and make sum 3. Take input from another
     * method and add 100 with that method input and make sum
     *
     * 4. A. Make a method for checking odd even number B. write another method
     * and print sum of odd and even with bonus. if number is odd , bonus will
     * be 10, otherwise bonus is 5
     */
    public static void main(String[] args) {
        new Quiz().printOddEvenSum(1, 10);
    }

    public void printOddEvenSum(int n1, int n2) {
        int oddNum = 0, evenNum = 0;
        for (int i = n1; i <= n2; i++) {
            if (checkOdd(i)) {
                oddNum += i;
                oddNum += 10;
            } else {
                evenNum += i;
                evenNum += 5;
            }
            //   System.out.println("Odd: " + oddNum + " Even " + evenNum);
        }
        System.out.println("Final Odd: " + oddNum + " Even " + evenNum);
    }

    public boolean checkOdd(int num) {
        if (num % 2 == 1) {
            return true;
        }
        return false;
    }

}
