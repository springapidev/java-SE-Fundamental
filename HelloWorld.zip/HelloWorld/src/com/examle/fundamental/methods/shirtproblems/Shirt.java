package com.examle.fundamental.methods.shirtproblems;

public class Shirt {

    private final int id;
    private final String color;
    private final char size;
    private final double price;

    public Shirt(int id, String color, char size, double price) {
        this.id = id;
        this.color = color;
        this.size = size;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public String getColor() {
        return color;
    }

    public char getSize() {
        return size;
    }

    public double getPrice() {
        return price;
    }

    

}
