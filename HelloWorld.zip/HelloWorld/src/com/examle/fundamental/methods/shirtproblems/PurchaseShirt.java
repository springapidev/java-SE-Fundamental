package com.examle.fundamental.methods.shirtproblems;

public class PurchaseShirt {

    public static void main(String[] args) {
        Shirt[] shirts = new Shirt[9];
        shirts[0] = new Shirt(1, "White", 's', 1500.00);
        shirts[1] = new Shirt(2, "White", 'm', 1600.00);
        shirts[2] = new Shirt(3, "White", 'l', 1700.00);
        shirts[3] = new Shirt(4, "Blue", 's', 2500.00);
        shirts[4] = new Shirt(5, "Blue", 'm', 2600.00);
        shirts[5] = new Shirt(6, "Blue", 'l', 2700.00);
        shirts[6] = new Shirt(7, "Red", 's', 3500.00);
        shirts[7] = new Shirt(8, "Red", 'm', 3600.00);
        shirts[8] = new Shirt(9, "Red", 'l', 3700.00);

//        double shirt1Price = Util.getSelectedShirtPrice(shirts, "Blue", 'm');
//        double shirt2Price = Util.getSelectedShirtPrice(shirts, "White", 's');
        // double totalAmount = shirt1Price + shirt2Price;
        // System.out.println("Total Price: " + totalAmount);
        double totalPrice = 0.0;
        for (Shirt ss : Util.getCart(shirts)) {
            totalPrice += ss.getPrice();
            Util.displayInfo(ss);

        }
        System.out.println("Total Price: " + totalPrice);

    }
}
