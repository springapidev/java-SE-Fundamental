package com.examle.fundamental.methods.shirtproblems;

public class Util {

//    public static double getSelectedShirtPrice(Shirt[] shirts, String color, char size) {
//        double priceOfSelectedShirt = 0.0;
//        for (Shirt s : shirts) {
//            if (s.getColor() == color && s.getSize() == size) {
//                priceOfSelectedShirt = s.getPrice();
//            }
//        }
//
//        return priceOfSelectedShirt;
//    }
    public static Shirt getSelectedShirt(Shirt shirt, String color, char size) {
        Shirt selctedShirt = null;

        if (shirt.getColor() == color && shirt.getSize() == size) {
            selctedShirt = new Shirt(shirt.getId(), shirt.getColor(), shirt.getSize(), shirt.getPrice());
        }

        return selctedShirt;
    }

    public static Shirt[] getCart(Shirt[] shirts) {
        Shirt[] shopingCart = new Shirt[2];
        for (Shirt s : shirts) {

            if (Util.getSelectedShirt(s, "Blue", 'm') != null) {
                shopingCart[0] = s;
            }
            if (Util.getSelectedShirt(s, "White", 's') != null) {
                shopingCart[1] = s;
            }

        }
        return shopingCart;
    }

    public static void displayInfo(Shirt shirt) {
        System.out.println("ID: " + shirt.getId() + " COlor: " + shirt.getColor() + " Size: " + shirt.getSize() + " Price: " + shirt.getPrice());
    }

}
