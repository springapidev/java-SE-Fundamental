package com.examle.fundamental.methods;

public class OddNumList {

    public static void main(String[] args) {
        new OddNumList().printOddNumbers(1, 20);
    }

    public void printOddNumbers(int n1, int n2) {
        for (int i = n1; i <= n2; i++) {
            if (new MethodProblem().isCheckOdd(i)) {
                System.out.print(i + ", ");
            }
        }

    }
}
