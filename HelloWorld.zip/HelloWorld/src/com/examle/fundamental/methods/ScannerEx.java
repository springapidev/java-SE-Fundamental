package com.examle.fundamental.methods;

import java.util.Scanner;

public class ScannerEx {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("Enter  A Int Number");
        // int num = sc.nextInt();
//
//        if (MethodProblem.isCheckOdd(num)) {
//            System.out.println("Odd Number");
//        } else {
//            System.out.println("Even...");
//        }
        System.out.println(makeSum());
    }

    public static int makeSum() {
        // Initialize sum and count of input elements 
        int sum = 0;
        // Check if an int value is available 
        while (sc.hasNextInt()) {
            // Read an int value 
            int num = sc.nextInt();
            sum += num;

        }

        return sum;
    }

}
