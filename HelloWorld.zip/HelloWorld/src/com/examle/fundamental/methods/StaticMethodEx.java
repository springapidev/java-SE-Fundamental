package com.examle.fundamental.methods;

public class StaticMethodEx {

    public static void main(String[] args) {
        StaticMethodEx.display();
        StaticMethodEx ob = new StaticMethodEx();
        ob.display2();
    }

    public static void display() {
        System.out.println("I am static and I am called without "
                + "object intitialized");
    }

    public void display2() {
        System.out.println("I am Non static and I am called with "
                + "object intitialized");
    }
}
