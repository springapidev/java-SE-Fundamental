package com.examle.fundamental.methods.bankProblems;

public class Test {

    public static void main(String[] args) {
        Account a1 = new Account(100, "Mr. A", 500.00, 500.00);
        Util.deposit(a1, 1200);
        Util.deposit(a1, 200);
        Util.withdraw(a1, 100);
        Util.withdraw(a1, 300);
        System.out.println("Balance: " + Util.checkBalance(a1));
        Util.withdraw(a1, 6600);
        System.out.println("Balance: " + Util.checkBalance(a1));
        Util.deposit(a1, 5000);
        System.out.println("Balance: " + Util.checkBalance(a1));
    }

}
