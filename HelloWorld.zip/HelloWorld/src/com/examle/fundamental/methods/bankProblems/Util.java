package com.examle.fundamental.methods.bankProblems;

public class Util {

    public static Account deposit(Account account, double amount) {
        double balance = account.getBalance() + amount;
        account.setBalance(balance);
        return account;
    }

    public static Account withdraw(Account account, double amount) {

        if (account.getBalance() >= amount) {
            double balance = account.getBalance() - amount;
            account.setBalance(balance);
        }

        return account;
    }

    public static double checkBalance(Account account) {
        return account.getBalance();
    }

   
}
