package com.examle.fundamental.methods.bankProblems;

public class Account {

    private int accountNo;
    private String name;
    private double openingDeposit;
    private double balance;

    public Account(int accountNo, String name, double openingDeposit, double balance) {
        this.accountNo = accountNo;
        this.name = name;
        this.openingDeposit = openingDeposit;
        this.balance = balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public int getAccountNo() {
        return accountNo;
    }

    public String getName() {
        return name;
    }

    public double getOpeningDeposit() {
        return openingDeposit;
    }

    public double getBalance() {
        return balance;
    }

}
