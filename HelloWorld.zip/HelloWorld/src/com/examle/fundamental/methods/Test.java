package com.examle.fundamental.methods;

public class Test {

    static int n2 = 100;

    public static void main(String[] args) {
// call a method
//        int valFromMethod = new Test().makeSum(10, 15);
//        System.out.println(valFromMethod);
//        System.out.println(new Test().makeSum(10, 15));
//        System.out.println(new Test().makeSum(new Test().makeSum(10, 15)));
//        System.out.println(new Test().makeSum());

        System.out.println(new Test().makeSum(10, 15L));

    }
//1. input as argument

    public int makeSum(int n1, int n2) {//1. inputed
        int sum = n1 + n2;//2. procesed 
        return sum;//3. return
    }

    //2. input as direct using global variable scope
    public int makeSum(int n1) {
        //1. n2 as global input
        int sum = n1 + this.n2;//2. procesed 
        return sum;//3. return
    }

    //3. input as method
    public int makeSum() {
        int rs = sumFromOneToFive();// 1 input
        int sum = rs + 100; // 2. process
        return sum;//3. return
    }

    public int sumFromOneToFive() {
        int sum = 0;
        for (int i = 1; i <= 5; i++) {
            sum += i;
        }
        return sum;
    }

    public int makeSum(long n1, int n2) {//1. inputed
        int sum = (int) n1 + n2;//2. procesed 
        return sum;//3. return
    }

    public int makeSum(int n2, long n1) {//1. inputed
        int sum = (int) n1 + n2;//2. procesed 
        return sum;//3. return
    }

    public void display() {
        System.out.println("Simple Method without Return Type");
    }
}
