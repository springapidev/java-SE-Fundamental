package com.examle.fundamental.abstracts;

public abstract class Animal {

    abstract void eat();

    abstract void run();

    void sleep() {
        System.out.println("Animal can sleep");
    }
}
