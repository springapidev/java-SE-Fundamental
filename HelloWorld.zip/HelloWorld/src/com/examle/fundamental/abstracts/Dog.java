package com.examle.fundamental.abstracts;

public class Dog extends Animal {

    @Override
    void eat() {
        System.out.println("Dog Can eat");
    }

    @Override
    void run() {
        System.out.println("Dog Can eat");
    }

    @Override
    void sleep() {
        System.out.println("Dog Can sleep");
    }

}
