package com.examle.fundamental.abstracts;

public class Test {

    public static void main(String[] args) {
        Animal a1 = new Dog();
        a1.eat();
        a1.sleep();
    }

}
