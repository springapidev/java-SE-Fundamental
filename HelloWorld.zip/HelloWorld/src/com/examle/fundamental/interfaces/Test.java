package com.examle.fundamental.interfaces;
public class Test {
    public static void main(String[] args) {
        Animal a1=new Tiger();
        a1.run();
    }
   
}
