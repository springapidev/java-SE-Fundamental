package com.examle.fundamental.interfaces;

public class Dog implements Animal {

    @Override
    public void eat() {
        System.out.println("Dog can eat");
    }

    @Override
    public void run() {
        System.out.println("Dog can run");
    }

    @Override
    public void ok() {
        Animal.super.ok(); //To change body of generated methods, choose Tools | Templates.
    }
   

}
