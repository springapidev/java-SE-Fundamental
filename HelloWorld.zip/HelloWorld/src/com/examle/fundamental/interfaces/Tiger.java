package com.examle.fundamental.interfaces;

public class Tiger extends Cat implements Animal, Animal2{

    @Override
    public void eat() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void run() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void hunt() {
        Animal.super.hunt(); //To change body of generated methods, choose Tools | Templates.
    }

   
    
}
