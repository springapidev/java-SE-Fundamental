package com.examle.fundamental.interfaces;
public class Cat {
    
}
