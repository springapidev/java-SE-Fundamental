package com.examle.fundamental.interfaces;

public interface Animal {

    void eat();

    void run();

    default void hunt() {

    }

    default void ok() {

    }

    static void play() {
    }
}
