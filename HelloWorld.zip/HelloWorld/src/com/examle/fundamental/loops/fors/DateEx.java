package com.examle.fundamental.loops.fors;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.chrono.JapaneseDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DateEx {

    public static void main(String[] args) {
        LocalDate d1 = LocalDate.of(2019, 01, 10);
       
        Date now = new Date();
        int day = now.getDay();

        System.out.println("Day: " + day);

        LocalDate llDate = LocalDate.now().plusMonths(2).minusDays(2);
        System.out.println(llDate);
        System.out.println("====================");

        String str = "12-10-1985";
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        try {
            Date dd = df.parse(str);
            System.out.println("dd: " + dd);

        } catch (ParseException ex) {
            Logger.getLogger(DateEx.class.getName()).log(Level.SEVERE, null, ex);
        }

        Date date = new Date();
        System.out.println("Date: " + date);

        long d = System.currentTimeMillis();
        System.out.println("ms: " + d);
        Date dateFromMs = new Date(d);
        System.out.println("dateFromMs " + dateFromMs);

        System.out.println(new Date());
        System.out.println("===============");
        LocalDate localDate = LocalDate.now();
        System.out.println("localDate " + localDate);
        JapaneseDate japaneseDate = JapaneseDate.from(localDate);
        System.out.println("japaneseDate : " + japaneseDate);

        LocalDate ld = LocalDate.MAX;
        System.out.println("ld: " + ld);
        LocalDate md = LocalDate.MIN;
        System.out.println("md: " + md);

        LocalDate likDate = LocalDate.of(1980, 1, 31);
        System.out.println("likDate: " + likDate);

        LocalDate d2 = LocalDate.of(2019, 01, 07);
        LocalDateTime localDateTime = LocalDateTime.now();
        d1.format(DateTimeFormatter.ISO_DATE);
    }
}
