package com.examle.fundamental.loops.fors;

import java.util.Arrays;

public class Test {

    public static void main(String[] args) {
        int[] nums = {1, 2, 3, 4, 5, 6, 7};
        for (int i = nums.length - 1; i >= 0; i--) {
            String comma = (i > 0) ? ", " : " ";
            //     System.out.print(nums[i] + "" + comma);
        }

        System.out.println("=====sorted array===");
        int unSortedNum[] = {5, 6, 1, 3, 4};// asc print
        
        int min = 0;
        for (int i = 0; i < unSortedNum.length - 1; i++) {
            for (int j = i + 1; j < unSortedNum.length; j++) {
                if (unSortedNum[i] > unSortedNum[j]) {
                    min = unSortedNum[j];//1
                    unSortedNum[j] = unSortedNum[i];//5
                    unSortedNum[i] = min;//1
                }
            }
        }

        for (int s : unSortedNum) {
            System.out.print(s + ", ");
        }
        System.out.println("========");
        first:
        for (int i = 1; i <= 5; i++) {
            System.out.println();
            second:
            for (int j = 1; j <= 10; j++) {

                if (j == 3) {
                    continue first;
                }
                System.out.print(j + " ");
            }
            //  break;
        }

    }

}
