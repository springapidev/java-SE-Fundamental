package com.examle.fundamental.loops.fors;

public class TwoDArray {

    public static void main(String[] args) {
        int[][] twoD = {
            {4, 8, 7, 9, 7},
            {1, 8, 7, 1, 5,8,88888}
        };
        System.out.println(twoD[1][5]);
        for (int[] oneD : twoD) {
            for (int i : oneD) {
                System.out.print(i + " ");
            }
            System.out.println();
        }
    }
}
