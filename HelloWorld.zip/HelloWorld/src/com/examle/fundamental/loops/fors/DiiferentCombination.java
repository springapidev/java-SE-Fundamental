package com.examle.fundamental.loops.fors;

public class DiiferentCombination {

    public static void main(String[] args) {
        printByLoop(1, 5, "DO");
    }

    public static void printByLoop(int num1, int num2, String loopName) {
        if (loopName == "FOR") {
            printByForLoop(num1, num2);
        } else if (loopName == "WHILE") {
            printByWhileLoop(num1, num2);
        } else {
            printByDoWhileLoop(num1, num2);
        }
    }

    public static void printByForLoop(int num1, int num2) {
        System.out.println("For Lopp");
        for (int i = num1; i <= num2; i++) {
            System.out.print(i + ", ");
        }
    }

    public static void printByWhileLoop(int num1, int num2) {
        System.out.println("While Lopp");
        while (num1 <= num2) {
            System.out.print(num1 + ", ");
            num1++;
        }
    }

    public static void printByDoWhileLoop(int num1, int num2) {
        System.out.println("Do While Lopp");
        do {
            System.out.print(num1 + ", ");
            num1++;
        } while (num1 <= num2);
    }

}
