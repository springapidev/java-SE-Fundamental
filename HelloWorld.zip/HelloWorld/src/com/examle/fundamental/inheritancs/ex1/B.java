package com.examle.fundamental.inheritancs.ex1;

public class B extends Bd {

    private int independentYear;

    public B(int independentYear, String nameOfCountry) {
        super(nameOfCountry);
        this.independentYear = independentYear;
    }

    @Override
    public String toString() {
        return "B{" + "independentYear=" + independentYear + '}';
    }
    
    
}
