package com.examle.fundamental.inheritancs.ex1;

public class Bd {

    public String nameOfCountry;

    public Bd() {
    }

    public Bd(String nameOfCountry) {
        this.nameOfCountry = nameOfCountry;
    }

    @Override
    public String toString() {
        return "Bd{" + "nameOfCountry=" + nameOfCountry + '}';
    }

  
    
}
