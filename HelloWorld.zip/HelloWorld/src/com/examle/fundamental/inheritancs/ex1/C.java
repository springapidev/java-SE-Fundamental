package com.examle.fundamental.inheritancs.ex1;

public class C extends A {

    private String flagSizeRatio;

    public C(String flagSizeRatio, float sqrtKm, String nameOfCountry) {
        super(sqrtKm, nameOfCountry);
        this.flagSizeRatio = flagSizeRatio;
    }

    public C(String flagSizeRatio, float sqrtKm) {
        super(sqrtKm);
        this.flagSizeRatio = flagSizeRatio;
    }

}
