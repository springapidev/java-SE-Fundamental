package com.examle.fundamental.inheritancs.ex1;

public class Test {

    public static void main(String[] args) {
        Bd bd1 = new Bd("BD.........");
        //  A bd2 = new Bd("BD.........");// wrong

        Bd a1 = new A(148570.0f, "Bangladesh");
        A a2 = new A(48570.0f, "Butan");

        System.out.println("A1 " + a1);
        System.out.println("A2 " + a2);
        ////////////////B
        Bd b1 = new B(1971, "Bangladesh");
        B b2 = new B(1945, "India");
        System.out.println("B1: " + b1);
        System.out.println("B2: " + b2);

        ////////////////C
        C c1 = new C("10:6", 148570, "Bangladesh");
        A c2 = new C("10:6", 148570, "Bangladesh");
        Bd c3 = new C("10:6", 148570, "Bangladesh");

    }

}
