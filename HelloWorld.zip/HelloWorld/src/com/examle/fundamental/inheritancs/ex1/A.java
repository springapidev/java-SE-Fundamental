package com.examle.fundamental.inheritancs.ex1;

public class A extends Bd {

    private float sqrtKm;

    public A(float sqrtKm) {
        this.sqrtKm = sqrtKm;
    }

    public A(float sqrtKm, String nameOfCountry) {
        super(nameOfCountry);
        this.sqrtKm = sqrtKm;
    }

    @Override
    public String toString() {
        return "A{" + "sqrtKm=" + sqrtKm + '}';
    }

}
