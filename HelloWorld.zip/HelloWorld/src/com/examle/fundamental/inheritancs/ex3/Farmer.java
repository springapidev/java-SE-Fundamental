package com.examle.fundamental.inheritancs.ex3;

public class Farmer {

    public void plough() {
        System.out.println("Normally Farmer ploughs rice in Bangladeh");
    }
}
