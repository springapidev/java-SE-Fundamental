package com.examle.fundamental.inheritancs.ex3;

public class People extends Farmer {

    @Override
    public void plough() {
        System.out.println("People also plough wheat in Bangladesh");
    }

}
