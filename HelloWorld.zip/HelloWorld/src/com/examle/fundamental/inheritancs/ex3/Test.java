package com.examle.fundamental.inheritancs.ex3;

public class Test {

    public static void main(String[] args) {
        People people1 = new People();
        people1.plough();// wheat

        Farmer people2 = new People();
        people2.plough();// wheat, run time polymorphism

        Farmer people3 = new Farmer();
        people3.plough();
    }
}
