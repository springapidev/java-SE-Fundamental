package com.examle.fundamental.inheritancs.ex4;

public final class Car {

    private String carModel;
}
