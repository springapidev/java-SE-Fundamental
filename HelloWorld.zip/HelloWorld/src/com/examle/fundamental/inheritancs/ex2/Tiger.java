package com.examle.fundamental.inheritancs.ex2;

public class Tiger extends Animal {

}
