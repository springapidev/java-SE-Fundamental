package com.examle.fundamental.inheritancs.ex2;

public class Dog extends Animal {

}
