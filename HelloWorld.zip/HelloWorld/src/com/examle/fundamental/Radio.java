package com.examle.fundamental;

public class Radio {

    int m;
    long n;
    byte o;
    int x, y, z;
    int p = 10, q = 20, r = 30;
    // Special type of variable / contant variable
    final float PI = 3.16f;// start with capital letters and all capitals
    final int NUMBER_OF_STUDENTS = 9;

    // another special thing in variable;
    long bigNum = 2545_789_545_545L;
}
