package com.examle.fundamental;

public class VariableFinalEx {
    /*
     1.  deleare multiple instance variable at the same type and initilization 
    and use it
     2. declare a constant variable
    
     */
}
