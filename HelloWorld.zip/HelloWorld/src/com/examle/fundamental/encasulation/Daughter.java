package com.examle.fundamental.encasulation;

public class Daughter extends RichMan{
    public static void main(String[] args) {
        RichMan richMan =new RichMan();
       
    }
 
}
