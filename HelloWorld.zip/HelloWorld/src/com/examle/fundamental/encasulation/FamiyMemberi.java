package com.examle.fundamental.encasulation;

public class FamiyMemberi {

    public static void main(String[] args) {
        RichMan obj = new RichMan();
        obj.oldCar = "Toyota.......";
        obj.carVeryOld = ".........";
    }

}
