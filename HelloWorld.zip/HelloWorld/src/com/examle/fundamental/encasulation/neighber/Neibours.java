package com.examle.fundamental.encasulation.neighber;

import com.examle.fundamental.encasulation.RichMan;

public class Neibours {
    public static void main(String[] args) {
        RichMan ob = new RichMan();
        ob.carForALl="Al..........";
    }
 
}
