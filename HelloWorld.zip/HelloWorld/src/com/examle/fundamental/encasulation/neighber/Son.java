package com.examle.fundamental.encasulation.neighber;

import com.examle.fundamental.encasulation.RichMan;


public class Son extends RichMan {

 

    public static void main(String[] args) {
        RichMan ob = new RichMan();
        ob.carForALl = "";
        Son son1 = new Son();
        son1.setNameOfCar("..........");
    }
}
