package com.examle.fundamental.encasulation;

public class Test {

    public static void main(String[] args) {
        EncapsulationEx obj = new EncapsulationEx();
        obj.name = "Mr. A";
        // obj.msg="Hello.....";// we can access, because msg is private at EncapsulatedEx
        obj.display();
    }

}
