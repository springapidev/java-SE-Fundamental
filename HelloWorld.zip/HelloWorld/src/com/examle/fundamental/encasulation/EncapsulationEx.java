package com.examle.fundamental.encasulation;

public class EncapsulationEx {

    public String name;// Not Encapsulated
    private String msg;//Encapsulated

    public void display() {
        System.out.println("I am not encasulated!!!");
    }
}
