package com.examle.fundamental.encasulation;

public class RichMan {

    private String nameOfCar;
    String oldCar;
    protected String carVeryOld;
    public String carForALl;

    public static void main(String[] args) {
        RichMan richMan = new RichMan();
        richMan.nameOfCar = "March...........";

    }

    public String getNameOfCar() {
        return nameOfCar;
    }

    public void setNameOfCar(String nameOfCar) {
        this.nameOfCar = nameOfCar;
    }

    public String getOldCar() {
        return oldCar;
    }

    public void setOldCar(String oldCar) {
        this.oldCar = oldCar;
    }

    public String getCarVeryOld() {
        return carVeryOld;
    }

    public void setCarVeryOld(String carVeryOld) {
        this.carVeryOld = carVeryOld;
    }

    public String getCarForALl() {
        return carForALl;
    }

    public void setCarForALl(String carForALl) {
        this.carForALl = carForALl;
    }
    
    
}
