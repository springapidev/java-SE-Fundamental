package com.examle.fundamental;

/**
 *
 * @author DBA
 * @since v-1.0.0
 */
public class HelloWorld {

    int p = 100;// instance variable

    static String msg = "Hello";// Best One , class variable
    static String message = new String("Hello");

    /**
     * @note we are printing Hello World
     * @param args
     */
    public static void main(String[] args) {
        // say hello world
        System.out.println(msg + " " + message);

        int x = 10;// decleration and initialization
        int y = x; // local variable
        int z = x + y;
        System.out.println(z);
        System.out.println(System.identityHashCode(x));
        System.out.println(System.identityHashCode(y));
        System.out.println(System.identityHashCode(z));
        System.out.println(System.identityHashCode(msg));
        System.out.println(System.identityHashCode(message));
        sayHi();
        System.out.println(sayHello());
        System.out.println(sayHello("Rabin Hood!"));
        int p = 200;
    }

    static void sayHi() {
        int p = 500;
        System.out.println(msg + " " + message);
    }

    static String sayHello() {
        return msg + " " + message;
    }

    static String sayHello(String msg) {
        //   String msg;// wrong
        String message = "Hi " + msg;

        return message;
    }

    public void testScope() {

        this.p = 2000;
        System.out.println("P: " + p);
    }

}
