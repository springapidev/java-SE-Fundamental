package com.examle.fundamental.constructors;

public class Student {

    private String name;
    private int age;
    private String color;
    private int birthYear;
    private double yearlyTusionFee;
    private boolean status;
    private int rollNo;

    public static Student viewStudent() {
        Student student = new Student("Mr. A", 34);
        return student;
    }

    public static void main(String[] args) {

        Student s2 = new Student();
        System.out.println("S2 Name: " + s2.name);

        Student s1 = viewStudent();
        System.out.println(s1.name);

    }

    public Student() {
    }

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public Student(int birthYear, String name) {
        this.name = name;
        this.birthYear = birthYear;
    }
/// wrong
//    public Student(String name, int rollNo) {
//        this.name = name;
//        this.rollNo = rollNo;
//    }

    public Student(String name, boolean status, int rollNo) {
        this.name = name;
        this.status = status;
        this.rollNo = rollNo;
    }

    public Student(String name, int age, String color, int birthYear, double yearlyTusionFee, boolean status) {
        this.name = name;
        this.age = age;
        this.color = color;
        this.birthYear = birthYear;
        this.yearlyTusionFee = yearlyTusionFee;
        this.status = status;
    }

}
