package com.examle.fundamental;

public class OperatorEx {

    public static void main(String[] args) {
        double x = 10;
        int y = 20;
        double rs = x / y;
        System.out.println("rs: " + rs);

        /////////////
        int p = 10;
        System.out.println(++p); // 11
        System.out.println(p++);//// 11
        System.out.println(p);//12

    }
}
