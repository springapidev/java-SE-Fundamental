package com.examle.fundamental.callownlibarary;

import com.coderbd.utils.FindSum;

public class TestSum {

    public static void main(String[] args) {
        int sum = FindSum.makeSum(1, 10);

        System.out.println(sum);
    }

}
