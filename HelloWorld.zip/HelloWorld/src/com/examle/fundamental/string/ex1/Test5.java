package com.examle.fundamental.string.ex1;

public class Test5 {

    static String greet = "How are you?";

    public static void main(String[] args) {
        System.out.println(greet.substring(0));//How are you?
        System.out.println(greet.substring(4));//are you?
        System.out.println(greet.substring(8));//you?
        System.out.println(greet.substring(4, 7));//are
        //   System.out.println(greet.substring(20, 30));//wrong
        System.out.println("Length Of String: " + greet.length());
    }

}
