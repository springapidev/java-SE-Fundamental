package com.examle.fundamental.string.ex1;

public class Test4 {

    static String greet = " How ";
    static String rs = greet.trim().concat("DY");
    static String phoneNo = "01686-23-91-46";

    static String alphabet = "ABBCDEFG";

    public static void main(String[] args) {
        System.out.println(rs);
        System.out.println(rs.toUpperCase());
        System.out.println(rs.toLowerCase());
        System.out.println(phoneNo.indexOf("-"));//5
        System.out.println(phoneNo.indexOf("-", 3));//5
        System.out.println(phoneNo.indexOf("-", 6));//8
        System.out.println(phoneNo.indexOf("-", 8));//8
        System.out.println(phoneNo.indexOf("-", 18));//-1
        System.out.println(phoneNo.indexOf("+", 18));//-1
        ////////////////////////////
        System.out.println("===========");
        System.out.println(alphabet.indexOf('C', 0));//-1
        System.out.println(alphabet.indexOf('C', 4));//-1

    }

}
