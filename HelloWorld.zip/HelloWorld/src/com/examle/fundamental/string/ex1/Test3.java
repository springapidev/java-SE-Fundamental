package com.examle.fundamental.string.ex1;

public class Test3 {

    private static String str1 = "Hello";
    private static String str2 = "Hello";
    private static String str3 = new String("Hello");
    private static String str4 = new String("Hello");

    private static String str5 = " World";
    private static String str6 = str1.concat(str5);
    private static String str7 = str1 + "" + str5;

    public static void main(String[] args) {
        System.out.println(System.identityHashCode(str1));
        System.out.println(System.identityHashCode(str2));
        System.out.println(System.identityHashCode(str3));
        System.out.println(System.identityHashCode(str4));
        //////////////////////
        System.out.println(str6);
        System.out.println(str7);
        System.out.println(str1 + "" + str5);
    }

}
