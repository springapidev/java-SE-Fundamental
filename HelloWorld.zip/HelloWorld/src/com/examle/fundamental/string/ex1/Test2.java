package com.examle.fundamental.string.ex1;

public class Test2 {

    String str4 = "Mr A";

    public static void main(String[] args) {
        new Test2().display();
        System.out.println("I am from Main Method");

    }

    static {
        System.out.println("I am from Static Block");
    }

    public Test2() {
        System.out.println("I am from default constructor");
    }

    public void display() {
        System.out.println("I am from method");
    }

}
