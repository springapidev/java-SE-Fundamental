package com.examle.fundamental.string.ex1;

public class Test9 {

    public static void main(String[] args) {
        int x = 10;
        String y = "10";
        boolean rs = x >= Integer.parseInt(y);
        int sum = x + Integer.parseInt(y);
        System.out.println("Rs: " + rs + " Sum: " + sum);

        String abc = "10Hellow";
        int intVal = Integer.parseInt(abc.substring(0, 2));
        int rsSum = intVal + x;
        System.out.println("rsSum: " + rsSum);

    }

}
