package com.examle.fundamental.string.ex1;

public class Test7 {

    private final int id;
    private final String name;

    public Test7(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

}
