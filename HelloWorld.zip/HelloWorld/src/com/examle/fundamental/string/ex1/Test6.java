package com.examle.fundamental.string.ex1;

public class Test6 {

    private static final int NUM_OF_STUDENTS = 15;//constant

    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder();
        sb.append("Hello");
        sb.append(" World");
        System.out.println(sb.toString());

        StringBuilder sb1 = new StringBuilder("Hello World");
        System.out.println(sb1);

      

    }

}
