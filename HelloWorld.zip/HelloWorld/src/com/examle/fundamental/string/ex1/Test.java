package com.examle.fundamental.string.ex1;

public class Test {

    String str1 = "Hello";
    String str2;
    static String str3;

    static {
        str3 = "Mr B";
    }

    public Test() {
        this.str2 = "Mr A";
    }

    public static void main(String[] args) {
        Test ob = new Test();

        System.out.println(ob.str1);
        System.out.println(ob.str2);
        System.out.println(str3);
    }
}
