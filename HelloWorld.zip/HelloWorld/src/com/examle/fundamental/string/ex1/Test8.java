package com.examle.fundamental.string.ex1;

public class Test8 {

    public static void main(String[] args) {
        int x = 10;
        long y = x;
        int z = (int) y;

        System.out.println("X: " + x);
        System.out.println("Y: " + y);
        long longVal = Long.MAX_VALUE;
        int intVal = Integer.MAX_VALUE;
        System.out.println("longVal: " + longVal);
        System.out.println("intVal: " + intVal);
        long ln = Integer.MAX_VALUE;
        int rs = (int) ln;
        System.out.println("RS " + rs);

    }

}
