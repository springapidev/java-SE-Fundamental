package com.examle.fundamental;

public class SwitchStatementEx {

    public static void main(String[] args) {
        int x = 12;
        switch (x) {
            default:
                System.out.println("Default");

            case 1:
                System.out.println("Case 1 is matched");

            case 2:
                System.out.println("Case 2 is matched");
                break;
            case 3:
                System.out.println("Case 3 is matched");
                break;
            case 4:
                System.out.println("Case 4 is matched");
                break;

        }

    }

}
