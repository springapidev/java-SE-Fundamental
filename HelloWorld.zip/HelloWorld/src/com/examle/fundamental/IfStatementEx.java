package com.examle.fundamental;

public class IfStatementEx {

    private static float mark = 91.0f;

    public static void main(String[] args) {

        int x = 10;
        int y = 50;

        if (!(x > 5 && x < y)) {
            System.out.println(x + " is greater than " + y);
        } else {
            System.out.println(x + " is less than " + y);
        }

        /////////call method
        showGrade(mark, 200);
    }

    public static void showGrade(float mark, float examHightestMark) {
        if (mark <= examHightestMark && mark >= 0) {

            if (mark >= 80) {
                System.out.println("A+");
            } else if (mark >= 70) {
                System.out.println("A");
            } else if (mark >= 60) {
                System.out.println("B");
            } else if (mark >= 45) {
                System.out.println("C");
            } else {
                System.out.println("F");
            }

        } else {
            System.out.println(mark + " is Invalid Mark");
        }

        showNestedIfExample(mark);
    }

    public static void showNestedIfExample(float obtainedMark) {
        if (obtainedMark >= 90 && obtainedMark <= 95) {
            if (obtainedMark % 2 == 0) {
                obtainedMark += 3; // obtainedMark = obtainedMark + 3;
                System.out.println("Mark: " + obtainedMark);
            } else {
                obtainedMark += 2; // obtainedMark = obtainedMark + 2;
                System.out.println("Mark: " + obtainedMark);
            }
        } else {
            System.out.println("Not eligible for Bonus Mark");
        }
    }
}
